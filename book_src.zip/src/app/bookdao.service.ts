import { HttpClient, HttpErrorResponse, HttpHeaders } from '@angular/common/http';
import { Injectable } from '@angular/core';
import { Observable } from 'rxjs';
import { throwError } from 'rxjs';
import { catchError } from 'rxjs/operators';

import { Book } from './model/book';

@Injectable({
  providedIn: 'root'
})
export class BookdaoService {

  baseUrl: string;
  httpOptions = {
    headers: new HttpHeaders({
      'Content-Type': 'application/json'
    })
  };

  constructor(private httpClient: HttpClient) {
    /*
    this.baseUrl = 'http://localhost:5000/books';
    */
    this.baseUrl = 'http://localhost:8081';
  }
  /*
  addBook(b: Book) {
    return this.httpClient.post<Book>(this.baseUrl, JSON.stringify(b), this.httpOptions).pipe(
      catchError(this.errorHandler)
    );
    // this.bookarr.push(b);
  }
  */
  addBook(b: Book) {
    console.log("inside addbook method r");
    return this.httpClient.post<Book>(this.baseUrl+"/addbook", JSON.stringify(b), this.httpOptions).pipe(
      catchError(this.errorHandler)
    );
    // this.bookarr.push(b);
  }
  
  deleteBook(id:number){
    return this.httpClient.delete<Book>(this.baseUrl+'/rembook/'+id).pipe(catchError(this.errorHandler))
  }

  searchBook(bookname: string) {
    return this.httpClient.get<Book>(this.baseUrl + "/book/" + bookname, this.httpOptions).pipe(
      catchError(this.errorHandler)
    )
  }

  editBook(b: Book) {
    console.log('edit book method');
    return this.httpClient.put<Book>(this.baseUrl + '/updatebook', JSON.stringify(b), this.httpOptions).pipe(
      catchError(this.errorHandler)
    )
  }

  getAllBooks() {
    return this.httpClient.get<Book[]>(this.baseUrl+"/allbooks", this.httpOptions).pipe(
      catchError(this.errorHandler)
    );
  }

  errorHandler(httpError: HttpErrorResponse) {
    let errorMessage = '';
    if (httpError.error instanceof ErrorEvent) {
      errorMessage = httpError.error.message;
    } else {
      errorMessage = `Error Code: ${httpError.status}\nMessage: ${httpError.message}`;
    }
    console.log(errorMessage);
    return throwError(() => httpError);
  }
}
