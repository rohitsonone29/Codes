import { Component, OnInit } from '@angular/core';
import { Router } from '@angular/router';
import { BookdaoService } from '../bookdao.service';
import { Book } from '../model/book';

@Component({
  selector: 'app-booklist',
  templateUrl: './booklist.component.html',
  styleUrls: ['./booklist.component.css']
})
export class BooklistComponent implements OnInit {
  bookarr: Book[];
  bookdao: BookdaoService;

  constructor(bookdao: BookdaoService,private router: Router) {
    this.bookarr = [];
    this.bookdao = bookdao;
  }

  ngOnInit(): void {
    this.bookdao.getAllBooks().subscribe(
      (data: Book[]) => {
        console.log(data);
        this.bookarr = data;
      }
    );
  }

  getAllBooks(){
    this.bookdao.getAllBooks().subscribe(
      (data: Book[]) => {
        console.log(data);
        this.bookarr = data;
      }
    );
  }
  deleteBook(bookid:number){
    this.bookdao.deleteBook(bookid)
    .subscribe(
      ()=>{
        console.log('book with bookid:'+bookid+'is deleted');
        this.getAllBooks();
      }
    )
  }
  /*
  updateBook(bookid:number){
    this.router.navigate(['bookupdate', bookid]);
  }
  */
}
