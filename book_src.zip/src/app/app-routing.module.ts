import { NgModule } from '@angular/core';
import { RouterModule, Routes } from '@angular/router';
import { BookformComponent } from './bookform/bookform.component';
import { BooklistComponent } from './booklist/booklist.component';
import { BooksearchComponent } from './booksearch/booksearch.component';
import { BookupdateComponent } from './bookupdate/bookupdate.component';

const routes: Routes = [
  {
    path: 'addBook',
    component: BookformComponent
  },
  {
    path: '',
    redirectTo: 'addBook',
    pathMatch: 'full'
  },
  {
    path: 'listBooks',
    component: BooklistComponent
  },
  {
    path: 'searchbook',
    component: BooksearchComponent
  },
  {
    path: 'update/:id/:name/:author',
    component: BookupdateComponent
  }
];

@NgModule({
  imports: [RouterModule.forRoot(routes)],
  exports: [RouterModule]
})
export class AppRoutingModule { }
