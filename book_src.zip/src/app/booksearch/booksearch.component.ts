import { Component, OnInit } from '@angular/core';
import { BookdaoService } from '../bookdao.service';
import { Book } from '../model/book';

@Component({
  selector: 'app-booksearch',
  templateUrl: './booksearch.component.html',
  styleUrls: ['./booksearch.component.css']
})
export class BooksearchComponent{
  bookname:string;
  book!:Book;
  constructor(private bookdao:BookdaoService){
    this.bookname='';
    //this.book=new Book(1,'','');
  }

  submitform(form:any){
    this.bookdao.searchBook(this.bookname).subscribe(
      (data)=>{
        this.book = data;
      }
    )
    console.log(this.book);
  }

}
