package junit.test;

public class MyUtils {
	

}
