package shapenotify;

public class MyThread1 extends Thread {


    @Override
    public void run() {
     //   synchronized {
            try{
                
            }catch(InterruptedException e){
                e.printStackTrace();
            }
           
        }
    }
}