package shapenotify;

public class MyThread2 implements Runnable{
	
	@Override
    public void run() {
        //synchronized () {
            try{
                
            }catch(InterruptedException e){
                e.printStackTrace();
            }
           
        }
    }
}
