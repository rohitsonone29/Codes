package shapenotify;

import java.util.PriorityQueue;
import java.util.Queue;

public class MyQueue {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Queue<Shape> q=new PriorityQueue<Shape>();
		
		
	}

}
