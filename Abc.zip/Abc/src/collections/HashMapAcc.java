package collections;

import java.util.*;

import customexception.Account;

public class HashMapAcc {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Map<Account,Double> h1 = new HashMap<Account,Double>();
		Account a = new Account("Rahul",10984,5000);
        Account a1 = new Account("Abhi",10890,45000);
        
        h1.put(a,a.getBalance());
        h1.put(a1,a1.getBalance());
        
        System.out.println(h1);
	}

}
