package collections;

import customexception.Account;
import java.util.Comparator;

public class ComparatorAcc implements Comparator<Account> {
	
	public int compare(Account a,Account a1)
    {
        System.out.println("comparing a.accno:"+a.getAcctNo()+" and a1.accno:"+a1.getAcctNo());
        return (int)(a.getAcctNo() - a1.getAcctNo());
    }

}
