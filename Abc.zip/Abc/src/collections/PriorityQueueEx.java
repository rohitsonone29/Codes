package collections;

import java.util.*;
public class PriorityQueueEx {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		//priorityQueue has element will sort elements priority wise
        //it uses comparable interface compareTo method for deciding the priority of elements added
		
		Queue<String> q=new PriorityQueue<String>();
		q.offer("Karan");
		q.offer("Harsh");
	
		q.offer("Gaurav");
		q.offer("Sham");
		
		 //peek returns ele at mouth of queue but doesnt remove it.
        //poll returns ele at moth of queue but also remove it from mouth of queue so that
        // next element then moves in to mouth
		
		System.out.println(q);
		System.out.println(q.size());
        System.out.println("peek:"+q.peek());
        System.out.println(q.size());
        System.out.println("poll:"+q.poll());
        System.out.println(q.size());
        System.out.println(q);
        
        

	}

}
