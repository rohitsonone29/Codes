package collections;

import java.util.Comparator;
import java.util.SortedSet;
import java.util.TreeSet;

import customexception.Account;
public class AccountsSort {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Comparator<Account> c = new ComparatorAcc();
		SortedSet<Account> st = new TreeSet<Account>(c);
		Account a = new Account("Rahul",10984,5000);
        Account a1 = new Account("Abhi",10890,45000);
        
        st.add(a);
        st.add(a1);
        
        
        System.out.println(st);
        
	}

}
