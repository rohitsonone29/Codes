package collections;

import java.util.Comparator;
import customexception.Account;
public class ComparatorAccNames implements Comparator<Account> {
	public int compare(Account a1,Account a2)
    {
        System.out.println("comparing e1.accname:"+a1.getAccountHolderName()+" and e2.accname:"+a2.getAccountHolderName());
        return (int)(a1.getAccountHolderName().compareTo(a2.getAccountHolderName()));
    }
}