package collections;

import java.util.*;

public class TreeEmpDept {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Comparator<Employee> c2 = new ComparatorEmpDept();
		SortedSet<Employee> set1 = new TreeSet<Employee>(c2);

        Employee e1 = new Employee(2,"Atharv Nirgude",25000,13);

        set1.add(e1);

        Employee e = new Employee(1,"Aman Sharma",15000,10);

        set1.add(e);


       // smp.put(new Employee(3,"Sangeeta Shah",35000,20),35000.0);
       // smp.put(new Employee(2,"Raj Malhotra",25000,10),25000.0);

        System.out.println(set1);
	}

}
