package collections;

import java.util.Comparator;

public class ComparatorEmpDept implements Comparator<Employee> {
	public int compare(Employee e1,Employee e2)
    {
        System.out.println("comparing e1.empname:"+e1.getDeptno()+" and e2.empname:"+e2.getDeptno());
        return (int)(e1.getDeptno()-(e2.getDeptno()));
    }
}
