package collections;

import java.util.Comparator;
import java.util.TreeMap;
import customexception.Account;
public class TreeMapAccName {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Comparator<Account> c1 = new ComparatorAccNames();
		TreeMap<Account,String> t1 = new TreeMap<Account,String>(c1);
		
		Account a = new Account("Rahul",10984,5000);
        Account a1 = new Account("Abhi",10890,45000);
        
        t1.put(a,a.getAccountHolderName());
        t1.put(a1,a1.getAccountHolderName());
        
        System.out.println(t1);
	}

}
