package callable;

import java.sql.SQLException;
import java.util.concurrent.Callable;
import java.util.concurrent.ExecutionException;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;
import java.util.concurrent.Future;
import java.util.concurrent.ThreadPoolExecutor;
import java.util.concurrent.TimeUnit;
 
public class CAssign {


    public static void main(String[] args)
    {
 
      ExecutorService ser1 = Executors.newFixedThreadPool(3);
       Callable<Integer> ob = new MyThread1();

       Future<Integer> f = ser1.submit(ob);

       Callable<Integer> ob1 = new MyThread2();

       Future<Integer> f1 = ser1.submit(ob1);


       while(!f.isDone()) {
           System.out.println("Task  is still not done...");
           try {
                Thread.sleep(200);
            } catch (InterruptedException e) {
                // TODO Auto-generated catch block
                e.printStackTrace();
            }
       }
 
      if(f.isDone() && !f.isCancelled())
      {
        System.out.println("Task completed! Retrieving the result");

           try
           {
             System.out.println("thread completed:returned value is:"+f.get());
           }
           catch(InterruptedException e)
           {
               e.printStackTrace();
           }
           catch(ExecutionException e)
           {
               e.printStackTrace();
           }



      }

       while(!f1.isDone()) {
           System.out.println("Task  is still not done...");
           try {
                Thread.sleep(200);
            } catch (InterruptedException e) {
                // TODO Auto-generated catch block
                e.printStackTrace();
            }
       }
      if(f1.isDone() && !f1.isCancelled())
      {
          System.out.println("Task completed! Retrieving the result");

           try
           {
             System.out.println("Callable thread completed:returned value is:"+f1.get());
           }
           catch(InterruptedException e)
           {
               e.printStackTrace();
           }
           catch(ExecutionException e)
           {
               e.printStackTrace();
           }


      }






      ser1.shutdown();
    }
 
}
 

class MyThread1 implements Callable<Integer>
{

    @Override
    public 
    {
   
    }
}
 
class MyThread2 implements Callable<Integer>
{
   
    @Override
    public Integer call() throws SQLException
    {

        int sum=0;
        System.out.println("inside Callable:Current Thread:"+Thread.currentThread().getName());
        for(int i=1;i<n;i++)
        {
          
        }


        return sum;

    }
}
 