package classesobjects;

public class InheritanceEx1 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Employee e;
		e=new Employee(1,"Rohit",23000,10);
		method(e);
		
		e=new WageEmployee(2,"Abhi",7000,20,8000,15);
		method(e);
		e=new Manager(101,"Kunal",35000,20,4,"Sales",80000);
	}
		
		public static void method(Employee e) {
	}

}
