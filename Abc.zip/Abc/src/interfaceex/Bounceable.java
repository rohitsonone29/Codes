package interfaceex;

public interface Bounceable {
	    int BOUNCE_FACTOR = 5;

	    void bounce();

	    void setBounceMultiple(int multiple);

}
