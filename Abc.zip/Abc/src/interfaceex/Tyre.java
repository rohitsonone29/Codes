package interfaceex;

public class Tyre implements Bounceable{
	
	public void bounce()
    {
       System.out.println("It's a "+ this.color+ " color ball bouncing with bounce factor = "+this.bf);    
    }

    public void setBounceMultiple(int multiple)
    {

        this.bf = Bounceable.BOUNCE_FACTOR * multiple;

    }
}
