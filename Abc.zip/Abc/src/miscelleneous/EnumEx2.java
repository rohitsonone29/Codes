package miscelleneous;

public class EnumEx2 {
	 
    public static void main(String[] args) {
        // TODO Auto-generated method stub
 
        CoffeeShop1 ob = new CoffeeShop1();
        ob.orderCoffee(CoffeeShop1.MugSize.JUMBO, CoffeeShop1.CofeeType.CAPPUCHINO);


    }
 
}
 

class CoffeeShop1
{
    int size;
    enum CofeeType {CAPPUCHINO,EXPRESSO,MOCHA};
 
    enum MugSize
    {
        SMALL(50),BIG(100),JUMBO(150);

        private int size;

        private MugSize(int size)
        {
            this.size =  size;
        }

        public int getSize()
        {
            return size;
        }
    }





    void orderCoffee(MugSize ms,CofeeType ct)
    {
        System.out.println("you have placed order for coffee "+ct.name()+" for size "+ms.name());

        System.out.println("you have placed order for coffee "+ct.ordinal()+" for size "+ms.getSize());
    }

}