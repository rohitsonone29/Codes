package com.rds.springboot.firstdemo;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.context.annotation.ComponentScan;
//@SpringBootApplication = @Configuration + @ComponentScan + @AutoConfiguration

//@ComponentScan(basePackages= {"com.nama.springboot.firstdemo","dao"})
@SpringBootApplication
public class FirstdemoApplication {

	public static void main(String[] args) {
		SpringApplication.run(FirstdemoApplication.class, args);
	}

}
