package com.util;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.edge.EdgeDriver;

public class WebBrowser {
	
	public static WebDriver OpenBrowser(String url)
	{
		System.setProperty("webdriver.edge.driver","src/test/resources/drivers/msedgedriver.exe");
		WebDriver driver= new EdgeDriver();
		driver.manage().window().maximize();
		driver.get(url);
		return driver;
	}
	
	public static String getTitle(WebDriver driver) {
		return driver.getTitle();
	}
}
