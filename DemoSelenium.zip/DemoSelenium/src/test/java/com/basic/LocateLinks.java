package com.basic;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;

import com.util.WebBrowser;

public class LocateLinks {
	WebDriver driver;
	
	@BeforeClass
	public void openPage() {
		driver=WebBrowser.OpenBrowser("https://www.google.co.in/");
	}
	
	@Test
	public void images()
	{
		driver.findElement(By.linkText("Images")).click();
		String acttitle=WebBrowser.getTitle(driver);
		assertEquals(acttitle.trim(),"Google Images");
		driver.navigate().back();
	}
	
	@Test
	public void advertising()
	{
		driver.findElement(By.linkText("Advertising")).click();
		assertEquals(WebBrowser.getTitle(driver).trim(),"Get More Customers with Easy Online Advertising | Google Ads");
		driver.navigate().back();
	}
	
	public void search()
	{
		driver.findElement(By.partialLinkText("Search")).click();
		String acttitle=WebBrowser.getTitle(driver);
		assertEquals(acttitle.trim(),"Google Search - Discover how Google Search works");
		driver.navigate().back();
	}

}
