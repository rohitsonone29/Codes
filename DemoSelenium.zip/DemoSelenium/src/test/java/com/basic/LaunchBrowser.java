package com.basic;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.edge.EdgeDriver;
import org.testng.annotations.Test;


public class LaunchBrowser {
	
	@Test
	public void OpenEdge()
	{
		System.setProperty("webdriver.edge.driver","src/test/resources/drivers/msedgedriver.exe");
		WebDriver driver= new EdgeDriver();
		driver.get("https://www.google.co.in/");
		driver.close();
		
	}
	

}
