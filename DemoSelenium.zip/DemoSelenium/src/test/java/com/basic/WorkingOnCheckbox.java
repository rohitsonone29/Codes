package com.basic;

import java.util.List;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.testng.annotations.Test;

import com.util.WebBrowser;

public class WorkingOnCheckbox {

	@Test
	public void selectCheckBox()
	{
		WebDriver driver=WebBrowser.OpenBrowser("https://mail.rediff.com/cgi-bin/login.cgi");
		WebElement chkbox=driver.findElement(By.id("remember"));
		
		if(!chkbox.isSelected())
		{
			chkbox.click();
		}
	}
	
	@Test
	public void selectCheckbox1()
	{
		WebDriver driver=WebBrowser.OpenBrowser("https://echoecho.com/htmlforms09.htm");
		List<WebElement> checkboxes=driver.findElements(By.cssSelector("td.table5>input"));
		for(WebElement ch : checkboxes)
		{
			if(ch.getAttribute("value").equals("Milk"));
			{
				if(!ch.isSelected())
				{
					ch.click();
					break;
				}
			}
		}
		for(WebElement ch : checkboxes)
		{
			if(ch.getAttribute("value").equals("Cheese"));
			{
				if(!ch.isSelected())
				{
					ch.click();
					break;
				}
			}
		}
	}

}
