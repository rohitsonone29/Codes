package autowiringanno;

public interface MyDatex  
{
	public int getMonth();
	public int getDate();
	public int getYear();
}
