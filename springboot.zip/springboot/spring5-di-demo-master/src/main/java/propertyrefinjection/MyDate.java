package propertyrefinjection;

public interface MyDate  
{
	public int getMonth();
	public int getDate();
	public int getYear();
}
