package com.rds.springboot.demo1.restful;

import org.springframework.web.bind.annotation.*;

@RestController
public class GreetService {
	
	@GetMapping("greet")
	public String greatAll() {
		System.out.println("HIIIIIII!!!!!");
		return "Hello World";
	}
	
	@GetMapping("greet1/{msg}")
    public String greetMsg(@PathVariable String msg)
    {
        System.out.println("msg="+msg);
        return "Hello "+msg;
    }

    @GetMapping("greet2")
    public String greetByName(@RequestParam String name)
    {
        System.out.println("name="+name);
        return "Hi "+name;
    }

    @GetMapping("greet3")
    public String greetByName(@RequestParam String name,@RequestParam String surname)
    {
        System.out.println(name+","+surname);
        return "Hi "+name+" "+surname;
    }

}
